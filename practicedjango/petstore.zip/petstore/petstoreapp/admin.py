from django.contrib import admin
from .models import pet

# Register your models here.
admin.site.register(pet)


